# Legacy facade package for `System.Reactive`

This package exists for backwards compatibility, and should not be used by new applications. Older versions of the Reactive Extensions for .NET (Rx) split types across various packages including this one.

Most applications using Rx today should reference `System.Reactive` directly.